// app.js
App({
    onLaunch() {
        // 初始化云开发
        wx.cloud.init({
            env: 'cloud1-6gx3s4yd98d193ce' // 云开发环境的ID
        })

        this.getOpenid()
        // 展示本地存储能力
        const logs = wx.getStorageSync('logs') || []
        logs.unshift(Date.now())
        wx.setStorageSync('logs', logs)

        // 登录
        wx.login({
            success: res => {
                // 发送 res.code 到后台换取 openId, sessionKey, unionId
            }
        })
    },
    //   获取openid
    getOpenid() {
        let app = this
        wx.cloud.callFunction({
            name: "getOpenid",
            success: (res) => {
                console.log('openid', res)
                app.globalData.openid = res.result.openid
            },
            fail: (res => {
                console.log('openid fail', res)
            })
        });
    },
    globalData: {
        userInfo: null,
        openid: null
    },
    // 获取当前时间
    _getYMD() {
        var d = new Date();
        var month = d.getMonth() + 1;
        var date = d.getDate();


        var curDateTime = d.getFullYear() + '年';
        if (month > 9)
            curDateTime += month + '月';
        else
            curDateTime += month + '月';

        if (date > 9)
            curDateTime = curDateTime + date + "日";
        else
            curDateTime = curDateTime + date + "日";

        return curDateTime;
    },
})