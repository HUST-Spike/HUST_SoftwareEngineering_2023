// pages/sign/sign.js
const app = getApp()
const db = wx.cloud.database()
const _ = db.command
Page({
    data: {
      // 日历配置
      calendarConfig: {
        // 隐藏农历
        showLunar: false,
        // 隐藏头部
        hideHeadOnWeekMode: true,
        // 主题
        theme: "elegant",
        // 高亮今天
        highlightToday: true,
        // 高亮周末
        highlightWeekend: true,
        // 选择模式
        chooseAreaMode: false,
        // 默认视图
        defaultDate: "2023-04-01",
      },
      // 日历数据
      calendar: {},
      // 连续签到天数
      signDays: 0,
      // 累计签到天数
      totalDays: 0,
      // 签到记录
      signRecords: [],
      // 高亮样式
      dayStyle:[
        //       {
        //       month: "current", day: new Date().getDate(), color: "white", background :"#AAD4F5"
        //   },
        ],
      // 日历翻到哪里
      currentData:{
          month: new Date().getMonth()+1,
          day: new Date().getDate(),
          year: new Date().getFullYear()
      }
    },
    // 页面加载时
    onLoad: function (options) {

      // 获取日历组件实例
      this.calendar = this.selectComponent("calendar");
      // 获取签到记录
      this.getSignRecords();
    },
    
    // 获取签到记录
    getSignRecords: function () {
      // 模拟从云数据库获取签到记录
      // 实际开发中，应该调用云函数或API获取数据
      let records = [
        {
          date: "2023-04-01",
          isSign: true,
        },
        {
          date: "2023-04-02",
          isSign: true,
        },
        {
          date: "2023-04-03",
          isSign: true,
        },
        {
          date: "2023-04-04",
          isSign: false,
        },
        {
          date: "2023-04-05",
          isSign: true,
        },
        {
          date: "2023-04-06",
          isSign: true,
        },
        {
          date: "2023-04-07",
          isSign: true,
        },
      ];

    //   累计签到数
      wx.cloud.database().collection('Users')
      .doc(app.globalData.openid).get().then((res)=>{
            this.setData({
                totalDays: res.data.signCount,
            });
      })

    //   日历记录
    // scoreDetail是所有分数的记录
    // 由于只有签到+10 和答对+5，简单做个区分，+10的就是签到的
      wx.cloud.database().collection('scoreDetail').get().then((res)=>{
        console.log("get sroceDetail", res.data)
        this.setData({
            signRecords: res.data.filter((item)=>{
                return item.detail == 10
            }).map((item)=>{
                return {
                    date: item.date,
                    isSign: true
                }
            }),
        });

        // 签到记录 this.data.signRecords
        console.log("sign records", this.data.signRecords)

        // 设置连续签到数 
        let count = 1;
        let i=this.data.signRecords.length-1;
        while(i>0 &&  
            Number(this.data.signRecords[i].date.split("月")[1].slice(0, -1)) -1  == 
            Number(this.data.signRecords[i-1].date.split("月")[1].slice(0, -1))  ){
                count++;
                i--;
        }
        this.setData({
            signDays: count
        })
        
        this.renderCalendar();
      })

    //   // 设置数据
    //   this.setData({
    //     signRecords: records,
    //   });
    // //   // 更新日历
    //   this.updateCalendar();
    // //   // 更新签到统计
    //   this.updateSignInfo();
    },
    // 渲染高亮
    renderCalendar:function(){
        // 根据记录来渲染日历
        this.setData({
            // 仅将当前年月的显示出来
            dayStyle: this.data.signRecords.filter((item)=>{
                let year  = item.date.slice(0, 4);
                let month = item.date.slice(5,7);
                return this.data.currentData.year == year && this.data.currentData.month == month
            }).map((item)=>{
                return {
                    month:"current", day: item.date.split("月")[1].slice(0, -1) , color: "white", background :"#AAD4F5"
                }
            })
        })
    },
    // 更新日历
    updateCalendar: function () {
      // 获取当前日期
      let today = this.calendar.getCurrentYM();
      // 获取签到记录
      let records = this.data.signRecords;
      console.log("records", records)
      // 遍历签到记录
      for (let record of records) {
        // 如果记录的日期是当前月份
        if (record.date.startsWith(today)) {
          // 获取记录的日期
          let date = record.date.slice(-2);
          // 如果记录是已签到
          if (record.isSign) {
            // 设置日期的颜色为绿色
            this.calendar.setDateStyle({
              year: today.slice(0, 4),
              month: today.slice(5, 7),
              day: date,
              color: "white",
              background: "#1aad19",
            });
          } else {
            // 如果记录是未签到
            // 设置日期的颜色为红色
            this.calendar.setDateStyle({
              year: today.slice(0, 4),
              month: today.slice(5, 7),
              day: date,
              color: "white",
              background: "#e64340",
            });
          }
        }
      }
    },
    // 更新签到统计
    updateSignInfo: function () {
      // 获取当前日期
      let today = this.calendar.getCurrentYM() + "-" + this.calendar.getCurrentDay();
      // 获取签到记录
      let records = this.data.signRecords;
      // 初始化连续签到天数
      let signDays = 0;
      // 初始化累计签到天数
      let totalDays = 0;
      // 遍历签到记录
      for (let record of records) {
        // 如果记录是已签到
        if (record.isSign) {
          // 累计签到天数加一
          totalDays++;
        }
      }
      // 从今天开始往前推算连续签到天数
      for (let i = 0; i < records.length; i++) {
        // 获取记录的日期
        let date = records[i].date;
        // 获取记录的签到状态
        let isSign = records[i].isSign;
        // 如果记录的日期是今天或之前的日期
        if (date <= today) {
          // 如果记录是已签到
          if (isSign) {
            // 连续签到天数加一
            signDays++;
          } else {
            // 如果记录是未签到
            // 停止循环
            break;
          }
        }
      }
      // 设置数据
      this.setData({
        signDays: signDays,
        totalDays: totalDays,
      });
    },
    // 点击日期
    onTapDay: function (e) {
      // 获取点击的日期
      let date = e.detail.year + "-" + e.detail.month + "-" + e.detail.day;
      // 获取签到记录
      let records = this.data.signRecords;
      // 遍历签到记录
      for (let record of records) {
        // 如果记录的日期是点击的日期
        if (record.date === date) {
          // 如果记录是已签到
          if (record.isSign) {
            // 提示用户已签到
            wx.showToast({
              title: "已签到",
              icon: "success",
            });
          } else {
            // 如果记录是未签到
            // 提示用户未签到
            wx.showToast({
              title: "未签到",
              icon: "none",
            });
          }
          // 停止循环
          break;
        }
      }
    },
        //监听点击下个月事件
    next: function (event) {
        console.log(event.detail);
        this.setData({
            currentData:{
                year: event.detail.currentYear,
                month:  event.detail.currentMonth
            }
        })
        this.renderCalendar();
    },
    //监听点击上个月事件
    prev: function (event) {
        console.log(event.detail);
        this.setData({
            currentData:{
                year: event.detail.currentYear,
                month:  event.detail.currentMonth
            }
        })
        this.renderCalendar();
    },
    // 监听点击日历标题日期选择器事件
    dateChange: function (event) {
        console.log(event.detail);
        this.setData({
            currentData:{
                year: event.detail.currentYear,
                month:  event.detail.currentMonth
            }
        })
        this.renderCalendar();
    },
    //监听点击日历具体某一天的事件
    dayClick: function (event) {
    console.log(event.detail);
    },
  });
