// pages/score/score.js
// 引入云开发数据库
const db = wx.cloud.database()
const app = getApp()

Page({
    data: {
        // 用户积分
        score: 0,
        // 积分明细列表
        scoreList: []
    },
    onLoad: function (options) {
        // 获取用户openid
        // 根据openid查询用户积分
        db.collection('Users').doc(app.globalData.openid).get()
            .then(res => {
                // 更新积分数据
                this.setData({
                    score: res.data.score
                })
            })
        // 根据openid查询用户积分明细
        db.collection('scoreDetail').where({
            _openid: app.globalData.openid
        }).orderBy('date', 'desc').get().then(res => {
            // 更新积分明细数据
            this.setData({
                scoreList: res.data
            })
        })
    }
})