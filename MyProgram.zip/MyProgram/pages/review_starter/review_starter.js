// pages/review_starter/review_starter.js
Page({
    // 点击错题查看按钮，跳转到mistake_review页面
    onMistakeReview: function (e) {
      wx.navigateTo({
        url: "/pages/wrong_view/wrong_view",
      });
    },
    // 点击错题重做按钮，跳转到mistake_redo页面
    onMistakeRedo: function (e) {
      wx.navigateTo({
        url: "/pages/wrong_redo/wrong_redo",
      });
    },
  });
  