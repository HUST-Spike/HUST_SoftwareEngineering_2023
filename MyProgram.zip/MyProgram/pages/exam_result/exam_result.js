// pages/practice/practice.js
Page({

    /**
     * 页面的初始数据
     */
    data: {
      rows: Array.from({
        length: 5
      }, (_, i) => i + 1),
      cols: Array.from({
        length: 10
      }, (_, i) => i + 1),
      bgColors: new Array(50),
      num: 0,
      total: 50,
    },
  
    back: function () {
      wx.redirectTo({
        url: '/pages/start/start',
      });
    },
  
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
      const db = wx.cloud.database(),
        wqs = db.collection('WQS'),
        bgColors = this.data.bgColors;
      let results = JSON.parse(options.results),
        questions = JSON.parse(options.questions);
      for (let i = 0; i < this.data.total; ++i) {
        if (results[i] == null) {
          bgColors[i] = 'white';
        } else if (results[i] == questions[i].result) {
          this.data.num++;
          bgColors[i] = 'lime';
        } else {
          bgColors[i] = 'red';
          wqs.add({
            data: {
              question: questions[i].question,
              result: questions[i].result,
              date: new Date()
            }
          })
        }
        this.setData({
          // lime
          num: this.data.num,
          bgColors: bgColors,
        });
      }
    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {
  
    },
  
    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {
  
    },
  
    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {
  
    },
  
    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {
  
    },
  
    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {
  
    },
  
    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {
  
    },
  
    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {
  
    }
  })