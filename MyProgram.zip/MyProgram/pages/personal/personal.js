// pages/profile/profile.js
const app = getApp()
Page({
    data: {
      // 用户信息
      userInfo: {
        avatarUrl: "", // 头像
        nickName: "", // 昵称
        signature: "", // 签名
      },
      // 统计数据
      stats: {
        signCount: 0, // 累计签到数
        friendCount: 0, // 好友数
        score: 0, // 积分
      },
      // 菜单列表
      menuList: [
        {
          name: "我的好友",
          icon: "friends",
          page: "friends",
        },
        {
          name: "我的签到",
          icon: "sign_check",
          page: "sign",
        },
        {
          name: "我的积分",
          icon: "star",
          page: "score",
        },
      ],
    //   修改签名
    changeSignature: false
    },
    // 页面加载时获取用户信息和统计数据
    onLoad: function (options) {
      this.getUserInfo();
      this.getStats();
    },
    // 获取用户信息
    getUserInfo: function () {
      // 调用微信接口获取用户信息
      wx.cloud.database().collection('Users')
      .doc(app.globalData.openid).get().then((res)=>{
          console.log("personal get res", res.data);
          this.setData({
            "userInfo.avatarUrl": res.data.avatarUrl,
            "userInfo.nickName": res.data.nickName,
            "userInfo.signature": res.data.signature,
          });
      })
        //    wx.getUserInfo这个接口没用

    //   // 从本地缓存获取用户签名
    //   let signature = wx.getStorageSync("signature");
    //   if (signature) {
    //       console.log(" 从本地缓存获取用户签名", signature)
    //     this.setData({
    //       "userInfo.signature": signature,
    //     });
    //   }
    },
    // 获取统计数据
    getStats: function () {
      // 从本地缓存获取统计数据
    //   let signCount = wx.getStorageSync("signCount");
    //   let friendCount = wx.getStorageSync("friendCount");
    //   let score = wx.getStorageSync("score");
    //   this.setData({
    //     "stats.signCount": signCount || 0,
    //     "stats.friendCount": friendCount || 0,
    //     "stats.score": score || 0,
    //   });

    //   云函数获取
      wx.cloud.database().collection('Users')
      .doc(app.globalData.openid).get().then((res)=>{
          console.log("personal get res", res.data);
          this.setData({
            "stats.signCount": res.data.signCount || 0,
            // "stats.friendCount":  res.data.friendCount || 0,
            "stats.score":  res.data.score || 0,
          });
      })

        // 调用云函数获取数据库中的好友记录
        wx.cloud.database().collection('Users')
        .orderBy('score', 'desc').get()
        .then(res => {
            this.setData({
                "stats.friendCount":  res.data.length,
              });
        })
 

    },
    // 点击返回键
    onBackTap: function () {
      // 跳转到start页面
      wx.navigateTo({
        url: "/pages/start/start",
      });
    },
    // 点击头像
    onAvatarTap: function () {
      // 跳转到avatar页面
      wx.navigateTo({
        url: "/pages/avatar/avatar",
      });
    },
    // 点击昵称
    onNickNameTap: function () {
      // 跳转到nickName页面
      wx.navigateTo({
        url: "/pages/nickName/nickName",
      });
    },
    // 点击签名
    onSignatureTap: function () {
      // 跳转到signature页面
    //   wx.navigateTo({
    //     url: "/pages/signature/signature",
    //   });
    this.setData({
        changeSignature: true
    })
    },
    // 点击菜单项
    onMenuTap: function (e) {
      // 获取菜单项的页面名称
      let page = e.currentTarget.dataset.page;
      // 跳转到对应的页面
      wx.navigateTo({
        url: "/pages/" + page + "/" + page,
      });
    },
    onChangeSignature:function(e){
        wx.cloud.database().collection('Users')
        .doc(app.globalData.openid)
        .update({
            data: {
                signature: e.detail.value,
            }
        })
    },
    onChooseAvatar(e) {
        const {
            avatarUrl
        } = e.detail

        // this.setData({
        //     "userInfo.avatarUrl": avatarUrl,
        // })
        // 发送数据
        wx.cloud.database().collection('Users')
            .doc(app.globalData.openid)
            .update({
                data: {
                    avatarUrl: avatarUrl,
                }
            }).then((res)=>{
                this.setData({
                    "userInfo.avatarUrl": avatarUrl
                  });
            })

    },
});

  
  