// pages/ranking/ranking.js
const app = getApp()
Page({
    data: {
        // 假设从后端获取的好友积分数据
        friends: [],
        // 假设从后端获取的当前用户的积分排名
        myRank: '',
    },
    onLoad: function (options) {
        // TODO: 从后端获取好友积分数据和当前用户的积分排名，并更新data
        wx.cloud.database().collection('Users')
            .orderBy('score', 'desc').get()
            .then(res => {
                console.log('排名', res)
                let list = res.data
                var ret2 = list.findIndex((v) => {
                    return v._id == app.globalData.openid;
                });
                this.setData({
                    friends: res.data,
                    myRank: ret2 + 1
                })
            })
    },
});