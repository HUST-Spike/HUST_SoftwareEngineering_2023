// pages/exam_starter/exam_starter.js
Page({
    data: {
      // 假设从后端获取的年级选项
      grades: ["一年级", "二年级", "三年级"],
      // 当前选择的年级索引，-1表示未选择
      gradeIndex: -1,
      // 当前选择的年级对应的year参数，0表示未选择
      year: 0,
    },
    onLoad: function (options) {
      // TODO: 从后端获取年级选项，并更新data
    },
    // 点击年级选择按钮，弹出下拉菜单
    onGradeSelect: function (e) {
      let that = this;
      wx.showActionSheet({
        itemList: that.data.grades,
        success: function (res) {
          // 更新选择的年级索引和year参数
          that.setData({
            gradeIndex: res.tapIndex,
            year: res.tapIndex + 1,
          });
        },
        fail: function (res) {
          console.log(res.errMsg);
        },
      });
    },
    // 点击开始练习按钮，跳转到exam页面
    onStartPractice: function (e) {
      let that = this;
      // 如果未选择年级，弹出提示框
      if (that.data.year == 0) {
        wx.showToast({
          title: "请选择您的年级数",
          icon: "none",
          duration: 2000,
        });
      } else {
        // 如果已选择年级，跳转到exam页面，并传入year参数
        wx.navigateTo({
          url: "/pages/exam/exam?grade=" + that.data.year,
        });
      }
    },
  });
  