// pages/practice/practice.js
const app = getApp()
const db = wx.cloud.database()
const _ = db.command
Page({

  /**
   * 页面的初始数据
   */
  data: {
    num: 1,
    total: 30,
    inputValue: "",
    inputLength: 4,
    hint: "",
    popHidden: true,
    wait_time: 1200,
    questions: [],
    question: "",
    queryResult:[],
    wait_time:3000
  },

  digitalClick: function (event) {
    var input = event.currentTarget.dataset.params;
    if (this.data.inputValue.length < this.data.inputLength)
      this.setData({
        inputValue: this.data.inputValue + input
      });
      console.log("输入，当前value",this.data.inputValue)      
      console.dir(this.data.question )

  },

  clearInput: function () {
    this.setData({
      inputValue: ""
    });
  },

  confirm: function () {
    const db = wx.cloud.database();
    const wqs = db.collection('WQS');
    if (parseInt(this.data.inputValue) == this.data.queryResult[this.data.num-1].result) {
      this.setData({
        hint: "恭喜你！\n答对啦！",
        popHidden: false
      });
      console.log("openId", app.globalData.openid)

        //   增加积分5
        wx.cloud.database().collection('Users')
        .doc(app.globalData.openid)
        .update({
            data: {
                score: _.inc(5),
            }
        }).then(res => {
            console.log("答对增加积分5")

            // 增加记录
            wx.cloud.database().collection('scoreDetail')
            .add({
                data: {
                    date: app._getYMD(),
                    detail: 5
                }
            }).then(res2 => {
                console.log('增加积分记录成功', res2)
            })

        }).catch(res => {
            console.log('增加积分失败', res)
        })

    } else {
      this.setData({
        hint: "糟糕 答错了\n正确答案为：" + this.data.queryResult[this.data.num-1].result,
        popHidden: false
      });
      wqs.where({
        _id: this.data.queryResult[this.data.num - 1]._id,
      }).remove();
      wqs.add({
        data: {
          question: this.data.queryResult[this.data.num-1].question,
          result: this.data.queryResult[this.data.num-1].result,
          date: new Date()
        }
      }).then().catch(console.error);
    }
    if (this.data.num < this.data.queryResult.length) {
        console.log("下一题")
      setTimeout(
        () => {
          this.setData({
            popHidden: true, // n秒后隐藏组件
            num: this.data.num + 1,
            question: this.data.queryResult[this.data.num].question,
            inputValue: ""
          });
        }, this.data.wait_time); // 这里的3000表示3000毫秒，即3秒
    } else {
        // 题目做完
        setTimeout(
            () => {
                this.setData({
                    hint: "恭喜你！错题已经全部做完",
                    popHidden: false
                });
            }, this.data.wait_time); // 这里的3000表示3000毫秒，即3秒

    };
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    wx.cloud.callFunction({
      name: "getWrongQuestions",
      data:{
        num:this.data.total
      }
    }).then(res => {
        console.log("onLoad getWrongQuestions", res.result.data)
      this.data.queryResult = res.result.data;
      this.data.querylength = res.result.data.length;
      var date2 = new Date();
      var date1 = new Date(res.result.data[this.data.num - 1].date); // 第一项的日期
      // date1.setHours(date1.getHours() - 8);
      // console.log(date2,date1);
      this.data.day = date2.getDay() - date1.getDay();
      if (this.data.day == 0) {
        this.setData({
          wrong_day: `出错日期：今天`,
        })
      } else if (this.data.day < 7) {
        this.setData({
          wrong_day: `出错日期：${this.data.day}天前`,
        })
      } else {
        this.setData({
          wrong_day: `出错日期：一周前`,
        })
      }

    //   
      this.setData({
        questions: this.data.queryResult.map((item)=>item.question),
        question: this.data.queryResult[this.data.num - 1].question
      })
    }).catch(console.error);
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})