const app = getApp()
const db = wx.cloud.database()
const _ = db.command
Page({
    data: {
        fadeout: "", // 定义一个空字符串，用来控制签到图片的动画
        hidden: true, // 定义一个布尔值，用来控制签到成功图片的显示和隐藏
        style: "" // 定义一个空字符串，用来控制签到成功图片的位置和大小
    },
    onLoad:function(){
        wx.cloud.database().collection('scoreDetail').where({
            detail: 10
          }).get().then((res)=>{
            console.log(res)
            res.data.findIndex((item)=>{
                let day = item.date.split("月")[1].slice(0, -1)
                let month = item.date.split("月")[0].split("年")[1]
                let today = new Date();
                if(day == today.getDate() && month == today.getMonth()+1){
                    this.setData({
                        fadeout: "hidden",
                        hidden: false
                    })
                }
            })
        })
    },
    sign: function () {
        this.setData({
            fadeout: "fadeout" // 点击签到图片后，设置fadeout为"fadeout"，触发动画
        })
        setTimeout(() => { // 设置一个延时函数，等待动画结束后执行
            this.setData({
                fadeout: "hidden" // 设置fadeout为"hidden"，隐藏签到图片
            })
            wx.createSelectorQuery().select('.icon').fields({ // 通过选择器查询，获取签到图片的节点信息，注意这里的选择器改为了'.icon'
                size: true,
                rect: true
            }, res => {
                res.top // 节点的上边界坐标
                res.left // 节点的左边界坐标
                res.width // 节点的宽度
                res.height // 节点的高度
            }).exec(res => {
                let style = `top: ${res[0].top}px; left: ${res[0].left}px; width: ${res[0].width}px; height: ${res[0].height}px;` // 根据节点信息，生成一个style字符串
                this.setData({
                    style: style // 把style字符串赋值给style
                })
                this.show() // 调用show函数，显示签到成功的图片
            })
        }, 1000) // 延时1秒
    },
    show: function () {
        this.setData({
            hidden: false // 设置hidden为false，显示签到成功图片
        })

        wx.cloud.database().collection('Users')
            .doc(app.globalData.openid)
            .update({
                data: {
                    score: _.inc(10),
                    signCount: _.inc(1),
                }
            }).then(res => {

                wx.cloud.database().collection('scoreDetail')
                    .add({
                        data: {
                            date: app._getYMD(),
                            detail: 10
                        }
                    }).then(res2 => {
                        console.log('签到成功', res2)
                    })
            }).catch(res => {
                console.log('签到失败', res)
            })
    }
})