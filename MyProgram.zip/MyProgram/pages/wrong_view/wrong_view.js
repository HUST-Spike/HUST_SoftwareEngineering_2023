// pages/practice/practice.js
Page({

    /**
     * 页面的初始数据
     */
    data: {
      total: 50,
      wrong_day: "出错日期：1天前",
      answer: 60,
      infoHidden: false,
      answerHidden: true,
      question: "",
      queryResult: null,
      num: 1,
      querylength: 0
    },
  
    view_answer: function () {
      this.setData({
        infoHidden: true,
        answerHidden: false
      })
    },
  
    next: function () {
      var date2 = new Date();
      var date1 = new Date(this.data.queryResult[this.data.num].date);
      // date1.setHours(date1.getHours() - 8);
      this.data.day = date2.getDay() - date1.getDay();
      if (this.data.day == 0) {
        this.setData({
          wrong_day: `出错日期：今天`,
        })
      } else if (this.data.day < 7) {
        this.setData({
          wrong_day: `出错日期：${this.data.day}天前`,
        })
      } else {
        this.setData({
          wrong_day: `出错日期：一周前`,
        })
      }
      this.setData({
        question: this.data.queryResult[this.data.num].question,
        answer: this.data.queryResult[this.data.num].result,
        num: this.data.num + 1,
        infoHidden: false,
        answerHidden: true
      });
    },
  
    delete: function () {
      const db = wx.cloud.database();
      const wqs = db.collection('WQS');
      wqs.where({
        _id: this.data.queryResult[this.data.num - 1]._id,
      }).remove();
      this.next();
    },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
      wx.cloud.callFunction({
        name: "getWrongQuestions",
        data:{
          num:this.data.total
        }
      }).then(res => {
        this.data.queryResult = res.result.data;
        this.data.querylength = res.result.data.length;
        var date2 = new Date();
        var date1 = new Date(res.result.data[this.data.num - 1].date);
        // date1.setHours(date1.getHours() - 8);
        // console.log(date2,date1);
        this.data.day = date2.getDay() - date1.getDay();
        if (this.data.day == 0) {
          this.setData({
            wrong_day: `出错日期：今天`,
          })
        } else if (this.data.day < 7) {
          this.setData({
            wrong_day: `出错日期：${this.data.day}天前`,
          })
        } else {
          this.setData({
            wrong_day: `出错日期：一周前`,
          })
        }
        this.setData({
          question: this.data.queryResult[this.data.num - 1].question,
          answer: this.data.queryResult[this.data.num - 1].result
        })
      }).catch(console.error);
    },
  
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {
  
    },
  
    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {
  
    },
  
    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {
  
    },
  
    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {
  
    },
  
    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {
  
    },
  
    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {
  
    },
  
    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {
  
    }
  })