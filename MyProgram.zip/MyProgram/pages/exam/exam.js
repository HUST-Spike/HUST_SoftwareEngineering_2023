// pages/practice/practice.js
Page({

    /**
     * 页面的初始数据
     */
    data: {
      showup: true,
      tableHidden: true,
      rows: Array.from({
        length: 5
      }, (_, i) => i + 1),
      cols: Array.from({
        length: 10
      }, (_, i) => i + 1),
      bgColors: null,
      num: 1,
      total: 50,
      inputValue: '',
      inputLength: 4,
      hint: "",
      popHidden: true,
      questions: Array,
      question: "",
      results: new Array(50),
      booltag: new Array(50).fill(false),
  
      time: 1800, // 倒计时的总秒数
      countdown: '' // 用于显示倒计时的字符串
    },
  
    skip: function (event) {
      const params = event.currentTarget.dataset.params;
  
      this.setData({
        popHidden: true, // n秒后隐藏组件
        question: this.data.questions[params - 1].question,
        num: params,
        showup: !this.data.showup,
        tableHidden: !this.data.tableHidden
      });
      if (this.data.booltag[params - 1]) {
        this.setData({
          inputValue: "" + this.data.results[params - 1]
        })
      } else {
        this.setData({
          inputValue: ""
        })
      };
    },
  
    digitalClick: function (event) {
      var input = event.currentTarget.dataset.params;
      if (this.data.inputValue.length < this.data.inputLength)
        this.setData({
          inputValue: this.data.inputValue + input
        });
    },
  
    upORdown: function () {
      this.setData({
        showup: !this.data.showup,
        tableHidden: !this.data.tableHidden
      });
    },
  
    clearInput: function () {
      this.setData({
        inputValue: ""
      });
    },
  
    confirm: function () {
      // const db = wx.cloud.database();
      // const wqs = db.collection('WQS');
      // if (parseInt(this.data.inputValue) == this.data.questions[this.data.num - 1].result) {
      //   this.setData({
      //     popHidden: false
      //   });
      // } else {
      //   this.setData({
      //     popHidden: false
      //   });
      //   wqs.add({
      //     data: {
      //       question: this.data.question,
      //       result: this.data.questions[this.data.num - 1].result,
      //       date: new Date()
      //     }
      //   }).then().catch(console.error);
      // }
      // 获取当前页面的数据
      const bgcolors = this.data.bgColors;
      // 修改数组 a 的第 k 个值
      bgcolors[this.data.num - 1] = 'lime';
      this.data.results[this.data.num - 1] = parseInt(this.data.inputValue);
      this.data.booltag[this.data.num - 1] = true;
      this.setData({
        bgColors: bgcolors,
      });
      if (this.data.num < this.data.total) {
        console.log(this.data.num, this.data.total);
        this.setData({
          question: this.data.questions[this.data.num].question,
          num: this.data.num + 1,
        });
        if (this.data.booltag[this.data.num - 1]) {
          this.setData({
            inputValue: "" + this.data.results[this.data.num - 1]
          })
        } else {
          this.setData({
            inputValue: ""
          })
        };
      }
    },
  
    handIn: function () {
      let questions = this.data.questions,
        results = this.data.results;
      wx.showModal({
        title: '提示',
        content: '确定交卷吗？',
        success(res) {
          if (res.confirm) {
            wx.redirectTo({
              url: '/pages/exam_result/exam_result?questions=' + JSON.stringify(questions) + '&results=' + JSON.stringify(results)
            });
          }
        }
      })
    },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
      let grade = options.grade;
      let numGrade = Number(grade);
      wx.cloud.callFunction({
          // 云函数名称
          name: 'generateProblems',
          // 传给云函数的参数
          data: {
            grade: numGrade,//grade
            num: this.data.total,
          },
        })
        .then(res => {
          this.data.questions = res.result.questions;
          // console.log(res.result.questions);
          this.setData({
            question: res.result.questions[0].question,
          })
        })
        .catch(console.error);
      this.setData({
        // lime
        bgColors: new Array(50).fill('white')
      })
      this.countDown();
  
    },
  
    countDown: function () {
      let time = this.data.time;
      let countdown = '';
      if (time >= 0) {
        let minute = Math.floor(time / 60);
        let second = time % 60;
        if (second < 10)
          countdown = minute + ':0' + second;
        else
          countdown = minute + ':' + second;
        time--;
        this.setData({
          time: time,
          countdown: countdown
        });
        setTimeout(this.countDown, 1000);
      } else {
        wx.showToast({
          title: '考试结束！！！', // 提示的内容
          icon: 'none', // 图标，有效值 "success", "loading", "none"
          duration: 2000 // 提示的延迟时间，单位毫秒，默认：1500
        });
        // 使用 setTimeout 延迟执行页面跳转
        setTimeout(() => {
          let questions = this.data.questions,
            results = this.data.results;
          wx.redirectTo({
            url: '/pages/exam_result/exam_result?questions=' + JSON.stringify(questions) + '&results=' + JSON.stringify(results)
          });
        }, 2000); // 注意此处的延迟时间应与 showToast 中的 duration 一致
      }
    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {
  
    },
  
    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {
  
    },
  
    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {
  
    },
  
    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {
  
    },
  
    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {
  
    },
  
    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {
  
    },
  
    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {
  
    }
  })