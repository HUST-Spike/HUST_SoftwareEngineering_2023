// pages/friends/friends.js
Page({
    data: {
      // 好友列表
      friendList: [],
    // 用户输入的好友id
       friendId: "",
    },
    // 页面加载时获取好友列表
    onLoad: function (options) {
          // 获取好友列表
        // 调用云函数获取数据库中的好友记录
        wx.cloud.database().collection('Users')
        .orderBy('score', 'desc').get()
        .then(res => {
            console.log('排名', res)
            let list = res.data
            this.setData({
                friendList: res.data,
            })
        })
    },

    // 点击好友头像
    onAvatarTap: function (e) {
      // 获取好友的id
      let id = e.currentTarget.dataset.id;
      // 跳转到friend页面，传递id参数
      wx.navigateTo({
        url: "/pages/friend/friend?id=" + id,
      });
    },
      // 点击添加好友按钮
    onAddFriendTap: function (e) {
    // 弹出一个带有输入框的模态对话框，让用户输入好友的id
    wx.showModal({
      title: "添加好友",
      content: "请输入好友的id",
      showCancel: true,
      cancelText: "取消",
      confirmText: "确认",
      inputType: "text",
      success: (res) => {
        // 如果用户点击了确认按钮
        if (res.confirm) {
          // 获取用户输入的id
          let id = res.inputValue;
          // 设置数据
          this.setData({
            friendId: id,
          });
          // 调用云函数查询数据库中是否存在这个id的用户
          wx.cloud.callFunction({
            name: "getUserById",
            data: {
              id: id,
            },
            success: (res) => {
              // 如果查询成功
              if (res.result.data.length > 0) {
                // 获取查询到的用户信息
                let user = res.result.data[0];
                // 调用云函数发送添加好友的请求
                wx.cloud.callFunction({
                  name: "addFriend",
                  data: {
                    user: user,
                  },
                  success: (res) => {
                    // 如果添加成功
                    if (res.result._id) {
                      // 提示用户发送请求成功
                      wx.showToast({
                        title: "发送请求成功",
                      });
                    }
                  },
                  fail: (err) => {
                    console.error(err);
                  },
                });
              } else {
                // 如果查询失败，提示用户输入错误
                wx.showToast({
                  title: "输入错误，请重新输入",
                  icon: "none",
                });
              }
            },
            fail: (err) => {
              console.error(err);
            },
          });
        }
      },
      fail: (err) => {
        console.error(err);
      },
    });
  },
  });
  