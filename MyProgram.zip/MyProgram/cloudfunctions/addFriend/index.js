// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV }) // 使用当前云环境

// 云函数入口函数
// 云函数入口函数
exports.main = async (event, context) => {
    // 获取查询到的用户信息
    let user = event.user;
    // 获取当前用户的openid
    let openid = cloud.getWXContext().OPENID;
    // 获取数据库引用
    const db = cloud.database();
    // 获取好友表
    const friendCollection = db.collection("friends");
    // 向好友表中添加一条记录，表示发送添加好友的请求
    return await friendCollection.add({
      data: {
        from: openid, // 发送请求的用户的openid
        to: user._id, // 接收请求的用户的_id
        status: 0, // 请求的状态，0表示未处理，1表示已同意，2表示已拒绝
        time: new Date(), // 请求的时间
      },
    });
  };