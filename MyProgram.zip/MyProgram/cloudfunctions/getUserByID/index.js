// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV }) // 使用当前云环境

// 云函数入口函数
exports.main = async (event, context) => {
  const wxContext = cloud.getWXContext()
  // 获取用户输入的id
  let id = event.id;
  // 获取数据库引用
  const db = cloud.database();
  // 获取用户表
  const userCollection = db.collection("users");
  // 查询用户表中是否存在这个id的用户
  return await userCollection.where({ id: id }).get();
}